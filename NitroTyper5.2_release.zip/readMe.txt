* Use Tampermonkey Extension with chrome
* Install / add race.user.js in TM

* That's all;
* Nitro Typer 5.2 will work perfectly after that.

* All commands and their uses is explained on my blog.

* My Site - https://www.theprabhakar.in

* Discord Server - https://discord.gg/ZtUvTxB


*****************************

Do you want to see Nitro Typer always up and working?

1. Hit like on Nitro Typer 5 video on YouTube.
	https://youtu.be/vNZLkJOVNCI
2. Subscribe to my YouTube Channel :->
	https://www.youtube.com/channel/UC4KqtdIrZucElkUUgma-79w
3. Visit my site and read some random articles :->
	https://www.theprabhakar.in
4. Join discord and message me.
	I will tell you; what you can do to support me.

*****************************

Regards	~ Madcap Hacker ~
	~ Have Fun! ~


*****************************

* Changelog:
* Updated to Version 5.1 (13-06-2020)
	* Maximum Race Limit in Multi Mode increased from 400 to 750
* Updated to Version 5.2 (12-09-2020)
	* Maximum Race Limit in Multi Mode increased from 750 to 1500
	* Now users can give custom range for speed and accuracy.
	* Disqualification and timeout shield added in advanced mode.